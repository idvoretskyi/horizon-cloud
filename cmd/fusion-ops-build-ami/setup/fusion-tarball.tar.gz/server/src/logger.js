'use strict';

const winston = require('winston');

module.exports = winston;
