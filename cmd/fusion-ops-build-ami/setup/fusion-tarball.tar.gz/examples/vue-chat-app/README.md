# RethinkDB Fusion Chat example using Vue.js

<center>![](https://i.imgur.com/XFostB8.gif)</center>

- [ ] implement `presence`
- [ ] implement `geo` to display users differently that are geographically near you
- [ ] implement `auth` to allow users to log in via Github, Twitter, etc and have their handle appear.
