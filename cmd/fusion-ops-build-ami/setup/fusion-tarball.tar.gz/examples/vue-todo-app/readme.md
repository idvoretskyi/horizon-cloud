# RethinkDB Fusion TodoMVC example using Vue.js

## Ideas for future

- [ ] implement `presence` for other connected people ToDo-ing


## Credit

This TodoMVC application was originally created by [Evan You](http://evanyou.me).
