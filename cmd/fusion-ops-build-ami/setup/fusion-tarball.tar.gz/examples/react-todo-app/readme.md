# React TodoMVC example using React

## Ideas for future

- [ ] implement `presence` for other connected people ToDo-ing

### Credit
Thanks to @todomvc for the original repo this was forked from.
